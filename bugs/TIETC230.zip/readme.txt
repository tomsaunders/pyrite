Title               : THE DENASI PLAGUE
Author              : FM/LT Dempsey/Cyclone 2-2/Wing X/ISD Challenge (#12519)
		      dempsey@slayersrealm.com
Platform            : TIE Fighter
Number of missions  : 5
Medal               : Medal of Parity


Required patches
----------------
* none


Installation instructions
--------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Check the Misc folder in your TIE95 one for additional material like patches, sounds etc.
3] Press the TIE Fighter button on the EHBL to start the game
4] Create a new pilot and fly the first battle






Introduction
-------------
While on a routine patrol mission, you run into what appears to be part of a massive 
New Republic fleet in Imperial space. It turns out the Republic is going to destroy a 
pirate force that has been a thorn in our side for quite a while now. Let's make sure 
they succeed...



DISCLAIMER
===========
THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.