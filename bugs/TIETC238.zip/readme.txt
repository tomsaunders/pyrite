Title               : Advance Warning
Author              : FL/MAJ Mark Schueler/Omega 9/SSSD Sovereign (#4182)
		      pilot4182@googlemail.com
Platform            : TIE Fighter
Number of missions  : 6
Medal               : none


Required patches
----------------
* none


Installation instructions
--------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Check the Misc folder in your TIE95 one for additional material like patches, sounds etc.
3] Press the TIE Fighter button on the EHBL to start the game
4] Create a new pilot and fly the first battle






Author's notes
--------------
Thanks to LC Tempest for his advice on balancing difficulties.



DISCLAIMER
===========
THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.