Title               : PACIFICATION
Author              : FL-PROF/LT Dempsey/Cyclone 3-1/Wing X/ISD Challenge (#12519)
		      dempsey@slayersrealm.com
Platform            : TIE Fighter
Number of missions  : 15
Medal               : Imperial Pacification Cross


Required patches
-----------------

* EHSP (http://sco.emperorshammer.net/patch/xvt/EHSP-XvT.zip)
* Corellian Gunship (http://sco.emperorshammer.net/patch/tie/GSP-TIE.zip)
* E-wing fighter (http://sco.emperorshammer.net/patch/tie/E-W-TIE.zip)



Installation instructions
--------------------------

1] Install the E-wing patch
2] Install the GSP patch
3] Double click the .EHM file, the EH Battle Launcher will install the battle
4] Use the EHBL to start the game and fly the battle


Introduction
-------------
You serve a tour of duty aboard the Victory class Star Destroyer Devastator, under the command
of Rear Admiral Plitkin. His mission is to remove the nuisance that is the Senaii: a rebellious
species governed by the Lord Protector of the Senaii. The way to achieve this is simple: total
pacification of the Senaii people. Their homeworld is to be destroyed, and their forces are to 
be eradicated. When we are through, they will be back in the stone age. Those that have survived 
anyway.
Fly fifteen missions for the Empire. Destroy the enemy and see to it peace is restored!


Known issues:
-------------
The animated briefing sometimes, but not always, crashes TIE95 for missions 9 and 15.


DISCLAIMER
===========
THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.