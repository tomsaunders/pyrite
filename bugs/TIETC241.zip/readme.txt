Title               : Operation Bourbon Run
Author              : FM/CM Conker Blackwood/Kappa 2-4/Wing VI/ISDII Warrior (#7697)
		      Conker_Blackwood@comcast.net
Platform            : TIE Fighter
Number of missions  : 8
Medal               : none


Required patches
----------------
* EH Ship Patch for TIE Fighter
* "Dunari's rest" Casino


Installation instructions
--------------------------
1] Make sure you have the EH Ship Patch for TIE Fighter installed
2] Download the "Dunari's Rest" Casino patch from the EH Patch archive (http://tc.emperorshammer.org/patcharchive.php)
3] Install the patch by double clicking it in the EHSP installer
4] Double click the .EHM file, the EH Battle Launcher will install the battle
6] Press the TIE Fighter button on the EHBL to start the game
7] Create a new pilot and fly Battle 1
8] Uninstall the patch by double clicking it in the EHSP installer



DISCLAIMER
===========
THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.