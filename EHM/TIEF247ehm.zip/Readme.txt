Title               : Docks and Drones
Author              : FM/COL Beef/Thunder 1-2/Wing X/ISD Challenge (Beefment@aol.com)
Platform            : TIE Fighter
Number of missions  : 1


DISCLAIMER
===========
THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.


Required patches
----------------
* EH Ship Patch for TIE Fighter
* TIE Drone


Installation instructions
--------------------------
1] Make sure you have the EH Ship Patch for TIE Fighter installed
2] Download the TIE Drone patch from the EH Patch archive (http://tc.emperorshammer.org/patcharchive.php)
3] Install the TIE Drone patch by double clicking it in the EHSP installer
4] Double click the .EHM file, the EH Battle Launcher will install the battle
5] Check the Misc folder in your XvT one for additional material like patches, sounds etc.
6] Press the TIE Fighter button on the EHBL to start the game
7] Create a new pilot and fly the first battle
8] Uninstall the TIE Drone patch by double clicking it in the EHSP installer



Description:
The SSD Avenger is docked for routine repairs and maintenance. It is at this vulnerable time that the TIE Drones that usually protect the shipyards contract a computer virus and begin attacking the repair crews. The base on the planet receives a distress call from the shipyard and sends two TIE Advanced to do what they can until more help can arrive.

THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY. ELEMENTS TM & � LUCASARTS ENTERTAINMENT COMPANY.

Colonel Beef
�Beefment@aol.com�

FM/COL Beef/Thunder 1-2/Wing X/ISD Challenge
GS/SS/BSx2/PCx8/ISMx12/MoT-9rh-11gh/CoB/LoAx10/OV-4E  
IS-1GW-2SW-2SR-3BW-2BR  {IWATS-GFX-SM/2-TM}  [LNGR] 
[T/D Mad Cow]    }:(:) -moo
	
	�Beefment@aol.com�
