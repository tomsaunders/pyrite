

Required patches
----------------
* none


Installation instructions
--------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Check the Misc folder in your TIE95 one for additional material like patches, sounds etc.
3] Press the TIE Fighter button on the EHBL to start the game
4] Create a new pilot and fly the first battle



THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.

EH Battle Center - http://battles.tiecorps.org
----------------------------------------------------
Corrected by Project Phoenix (December 10th, 1999) 
- Battle1.lfd file fixed.
- Debriefing questions fixed for all missions.
By CMDR/CPT Astin/Gimel/Wing III/SSSD Sovereign
- Small fixes in anim briefings
- Bugs corrected on mission 4,5 (number of ships) (26/07/00)
by CA:TAC/AD Striker/CA-3/SSSD Sovereign
