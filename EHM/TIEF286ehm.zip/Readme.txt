Title               : Rookie's First Day
Author              : LT Landon Cruise (#12975)
Platform            : TIE Fighter
Number of missions  : 1
Medal               : N/A



Required patches
-----------------
* none



Installation instructions (EHBL)
--------------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Press the TIE Fighter button on the EHBL to start the game
3] Create a new pilot and fly the first battle



Installation instructions (non-EHBL)
------------------------------------
1] Extract the .ZIP file
2] Copy the *.TIE files to your game's \MISSION folder 
3] Copy the BATTLE1.LFD file to your game's \RESOURCE folder
2] Start the game
3] Create a new pilot and fly the first battle



========================================================================================
----------------------------------------------------------------------------------------

THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.

----------------------------------------------------------------------------------------
========================================================================================



