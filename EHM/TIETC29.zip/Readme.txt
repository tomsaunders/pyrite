

Required patches
----------------
* none


Installation instructions
--------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Check the Misc folder in your TIE95 one for additional material like patches, sounds etc.
3] Press the TIE Fighter button on the EHBL to start the game
4] Create a new pilot and fly the first battle



THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.

Emperor's Hammer Battle Center - http://www.tiecorps.org/battles/
------------------------------------------------------------
Modified for Project Phoenix (Jan 31, 2000)
- Battle1.lfd file corrected
- Briefing corrected in all missions, don't push FORWARD button
 on the briefing map! Possible crash!
by: FL/CPT Wlodek/Pi 2-1/Wing VIII/ISD Colossus
- Animated briefings slightly corrected in all missions (Apr 2, 2000)
by: CA:TAC/AD Striker/CA-3/SSSD Sov