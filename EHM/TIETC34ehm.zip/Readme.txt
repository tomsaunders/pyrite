Required patches
----------------
* none


Installation instructions
--------------------------
1] Double click the .EHM file, the EH Battle Launcher will install the battle
2] Check the Misc folder in your TIE95 one for additional material like patches, sounds etc.
3] Press the TIE Fighter button on the EHBL to start the game
4] Create a new pilot and fly the first battle




THESE LEVELS ARE NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT COMPANY.
ELEMENTS TM & (c) LUCASARTS ENTERTAINMENT COMPANY.

Emperor's Hammer Battle Center - http://battles.tiecorps.org
------------------------------------------------------------
Corrected by Project Phoenix (Dec 7, 1999)
- Added file Readme.txt
by CA:FC/AD Danrik/CA-1/SSSD Sov
- All animated briefings quite redone
- A little thing added in debriefing #6..:P (26/07/00)
by CA:TAC/VD Striker/CA-3/SSSD Sov 
